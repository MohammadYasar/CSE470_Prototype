﻿CREATE TABLE [dbo].[log_info]
(
	[user_name] TEXT NOT NULL PRIMARY KEY, 
    [email_id] NVARCHAR(50) NOT NULL, 
    [password] NVARCHAR(50) NOT NULL
)
